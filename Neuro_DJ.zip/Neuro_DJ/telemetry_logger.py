"""
telemetry_logger.py — Neuro-DJ Evaluation Harness (Stage 1 & 2)
═════════════════════════════════════════════════════════════════
This module records the complete lifecycle of a single transition.
It captures the offline plan, the 10Hz live timeline, the executor's 
adaptations, and the final human evaluation into a single JSON artifact.
"""

import json
import os
import time
import uuid
from datetime import datetime
import threading

class TransitionTelemetry:
    def __init__(self, plan: dict, track_a_path: str, track_b_path: str, log_dir="logs/transitions"):
        self.log_dir = log_dir
        if not os.path.exists(self.log_dir):
            os.makedirs(self.log_dir, exist_ok=True)

        self.tx_id = f"tx_{int(time.time())}_{uuid.uuid4().hex[:6]}"
        self.start_time = datetime.now().isoformat()
        self._lock = threading.Lock()

        # 1. Static Metadata & Plan
        recipe = plan.get('recipe', {})
        self.metadata = {
            "track_a": os.path.basename(track_a_path),
            "track_b": os.path.basename(track_b_path),
            "technique_id": recipe.get('technique_id', 0),
            "technique_name": recipe.get('technique_name', 'UNKNOWN'),
            "planned_duration_beats": recipe.get('beats', 32),
            "mix_trigger_sec": plan.get('mix_trigger', 0.0)
        }

        # 2. Phrase Attribution (If phrase_analyzer was used)
        ctx = plan.get('ctx', {})
        self.phrase_attribution = {
            "a_exit_function": ctx.get('a_exit_func', 'unknown'),
            "a_exit_mixability": ctx.get('a_exit_mix', 0.0),
            "b_entry_function": ctx.get('b_entry_func', 'unknown'),
            "b_entry_mixability": ctx.get('b_entry_mix', 0.0),
            "key_compat": ctx.get('key_compat', 'unknown'),
            "bpm_delta": ctx.get('bpm_delta', 0.0)
        }

        # 3. Live Data Stores
        self.timeline_10hz = []
        self.adaptation_log = []
        self._tick_counter = 0

    def log_tick(self, beat_elapsed: float, state):
        """Called at 10Hz by the AdaptiveExecutor."""
        with self._lock:
            self._tick_counter += 1
            self.timeline_10hz.append({
                "tick": self._tick_counter,
                "beat": round(beat_elapsed, 2),
                "a_rms": state.a_rms,
                "b_rms": state.b_rms,
                "congestion": state.overlap_congestion,
                "phase_offset_beats": state.phase_offset_beats,
                "drift_conf": state.drift_confidence,
                "vocal_clash_live": state.vocal_clash_live,
                "b_groove_est": state.b_groove_established,
                "a_space_opened": state.a_space_opened,
                "readiness": state.readiness_score
            })

    def log_action(self, beat_elapsed: float, action_name: str, state):
        """Called by AdaptiveExecutor when it intervenes (e.g., DRIFT_NUDGE)."""
        with self._lock:
            self.adaptation_log.append({
                "beat": round(beat_elapsed, 2),
                "action": action_name,
                "trigger_state": {
                    "congestion": state.overlap_congestion,
                    "phase_offset": state.phase_offset_beats,
                    "drift_conf": state.drift_confidence,
                    "readiness": state.readiness_score
                }
            })

    def finalize_and_save(self, rating: int, failure_tags: list, notes: str = ""):
        """
        Called by the GUI after the user submits the RLHF rating.
        Uses atomic file writing to guarantee no corruption.
        """
        with self._lock:
            record = {
                "transition_id": self.tx_id,
                "timestamp": self.start_time,
                "metadata": self.metadata,
                "phrase_attribution": self.phrase_attribution,
                "evaluation": {
                    "rating": rating,
                    "failure_tags": failure_tags,
                    "notes": notes
                },
                "adaptation_log": self.adaptation_log,
                "timeline_10hz": self.timeline_10hz
            }

        file_path = os.path.join(self.log_dir, f"{self.tx_id}.json")
        tmp_path = file_path + ".tmp"
        
        try:
            with open(tmp_path, 'w') as f:
                json.dump(record, f, indent=2)
            os.replace(tmp_path, file_path)
            print(f"💾 Telemetry saved: {self.tx_id}.json")
        except Exception as e:
            print(f"⚠️ Failed to save telemetry: {e}")