"""
set_state.py — Neuro-DJ Set State Model
════════════════════════════════════════
Stage 10 of the roadmap: track the evolving state of the set.

A DJ doesn't make transition decisions in isolation. They track the room.
Three intense transitions in a row means the crowd needs a breather.
A 20-minute plateau at high energy means it's time for contrast.
Five vocal-heavy tracks means the crowd's ears are fatigued.

This module maintains a rolling model of the set state and exposes it
to the transition planner so technique and track choice are informed by
the full journey, not just the current pair.
"""

import time
import json
import os
from dataclasses import dataclass, field
from typing import List, Dict

@dataclass
class SetEvent:
    timestamp: float
    technique: str
    energy_a: str
    energy_b: str
    key_a: str
    key_b: str
    bpm: float
    vocal_clash_risk: bool = False
    duration_beats: int = 32

@dataclass
class SetStateSnapshot:
    mix_count: int
    session_duration: float
    energy_rolling: float
    intensity_rolling: float
    time_since_breather: float
    time_since_hard_drop: float
    vocal_density_fatigue: float
    novelty_rate: float
    harmonic_stability: float
    tempo_change_fatigue: float
    set_phase: str
    recent_energies: List[str]

class SetStateModel:
    TECHNIQUE_INTENSITY = {
        "BASS_SWAP": 0.60,
        "EQ_BLEND": 0.40,
        "FILTER_SWEEP": 0.50,
        "ECHO_THROW": 0.85,
        "SLOW_BURN": 0.20,
        "PIANO_HANDOFF": 0.55,
        "RHYTHM_RIDE": 0.70,
        "ECHO_FREEZE": 0.95
    }

    def __init__(self, filepath="set_history.json"):
        self.filepath = filepath
        self.history: List[SetEvent] = []
        self.session_start = time.time()
        self._load_state()

    def _load_state(self):
        if os.path.exists(self.filepath):
            try:
                with open(self.filepath, 'r') as f:
                    data = json.load(f)
                self.session_start = data.get("session_start", time.time())
                for ev in data.get("history", []):
                    self.history.append(SetEvent(**ev))
            except Exception as e:
                print(f"⚠️ Could not load set state: {e}. Starting fresh.")

    # 🛡️ ROCK SOLID UPDATE: Atomic File Saving
    def _save_state(self):
        """Saves the set state to disk atomically to prevent corruption."""
        try:
            tmp_file = self.filepath + ".tmp"
            with open(tmp_file, 'w') as f:
                json.dump({
                    "history": [vars(e) for e in self.history],
                    "session_start": self.session_start
                }, f, indent=4)
            # Atomic overwrite guarantees the file is never left half-written
            os.replace(tmp_file, self.filepath)
        except Exception as e:
            print(f"⚠️ Could not save set state: {e}")

    def update_transition(self, track_a: dict, track_b: dict, recipe: dict):
        """Called by neuro_gui.py after a successful transition swap."""
        ev = SetEvent(
            timestamp=time.time(),
            technique=recipe.get('technique_name', 'UNKNOWN'),
            energy_a=track_a.get('energy', 'High'),
            energy_b=track_b.get('energy', 'High'),
            key_a=track_a.get('key', 'C'),
            key_b=track_b.get('key', 'C'),
            bpm=track_b.get('bpm', 112.0),
            vocal_clash_risk=recipe.get('vocal_clash', False),
            duration_beats=recipe.get('beats', 32)
        )
        self.history.append(ev)
        self._save_state()

    def get_snapshot(self) -> SetStateSnapshot:
        """Calculates the current rolling state based on recent history."""
        recent = self.history[-4:] if len(self.history) >= 4 else self.history
        
        mix_count = len(self.history)
        session_dur = time.time() - self.session_start

        if not recent:
            return SetStateSnapshot(
                mix_count=0, session_duration=session_dur, energy_rolling=0.5,
                intensity_rolling=0.5, time_since_breather=0.0, time_since_hard_drop=0.0,
                vocal_density_fatigue=0.0, novelty_rate=0.5, harmonic_stability=1.0,
                tempo_change_fatigue=0.0, set_phase="warmup", recent_energies=[]
            )

        energies = [1.0 if e.energy_b == 'High' else 0.2 for e in recent]
        energy_rolling = sum(energies) / len(energies)

        intensities = [self.TECHNIQUE_INTENSITY.get(e.technique, 0.5) for e in recent]
        intensity_rolling = sum(intensities) / len(intensities)

        # Time since breather (Low/Chill track)
        last_breather_time = self.session_start
        for e in reversed(self.history):
            if e.energy_b == 'Low/Chill':
                last_breather_time = e.timestamp
                break
        time_since_breather = time.time() - last_breather_time

        # Time since hard drop (ECHO_FREEZE or ECHO_THROW)
        last_hard_drop = self.session_start
        for e in reversed(self.history):
            if e.technique in ("ECHO_FREEZE", "ECHO_THROW"):
                last_hard_drop = e.timestamp
                break
        time_since_hard_drop = time.time() - last_hard_drop

        vocal_fatigue = sum(1.0 for e in recent if e.vocal_clash_risk) / len(recent)

        # Set Phase logic
        phase = "build"
        if mix_count < 3: phase = "warmup"
        elif energy_rolling > 0.8 and intensity_rolling > 0.7: phase = "peak"
        elif time_since_breather < 180: phase = "breather"
        elif session_dur > 3600 and mix_count > 15: phase = "cooldown"

        return SetStateSnapshot(
            mix_count=mix_count,
            session_duration=session_dur,
            energy_rolling=energy_rolling,
            intensity_rolling=intensity_rolling,
            time_since_breather=time_since_breather,
            time_since_hard_drop=time_since_hard_drop,
            vocal_density_fatigue=vocal_fatigue,
            novelty_rate=0.5, # Placeholder for future expanded logic
            harmonic_stability=1.0,
            tempo_change_fatigue=0.0,
            set_phase=phase,
            recent_energies=[e.energy_b for e in recent]
        )

    def apply_to_scoring(self, base_scores: dict) -> dict:
        """
        Modifies technique base scores using the macro-level set state.
        This allows the AI to choose different transitions based on crowd fatigue.
        """
        adjusted = dict(base_scores)
        set_state = self.get_snapshot()

        # 1. Breather Recommendation
        if set_state.time_since_breather > 120 and set_state.energy_rolling > 0.7:
            adjusted["SLOW_BURN"]    = adjusted.get("SLOW_BURN", 0) + 40
            adjusted["FILTER_SWEEP"] = adjusted.get("FILTER_SWEEP", 0) + 25
            adjusted["ECHO_FREEZE"]  = adjusted.get("ECHO_FREEZE", 0) - 30
            print(f"   📉 Set state: Room needs a breather → boosting SLOW_BURN")

        # 2. Intensity Recommendation
        if set_state.time_since_hard_drop > 300 and set_state.energy_rolling < 0.5 and set_state.mix_count > 3:
            adjusted["ECHO_FREEZE"]  = adjusted.get("ECHO_FREEZE", 0) + 35
            adjusted["ECHO_THROW"]   = adjusted.get("ECHO_THROW", 0) + 25
            print(f"   📈 Set state: Room is too chill → boosting hard drops")

        # 3. Vocal Relief
        if set_state.vocal_density_fatigue > 0.75:
            adjusted["BASS_SWAP"] = adjusted.get("BASS_SWAP", 0) + 10
            adjusted["PIANO_HANDOFF"] = adjusted.get("PIANO_HANDOFF", 0) + 10
            print(f"   🔇 Set state: Vocal fatigue high → boosting EQ suppressions")

        # Variety rotation: prevent spamming the same high-energy trick
        if set_state.time_since_hard_drop < 120:
            adjusted["ECHO_FREEZE"]  = adjusted.get("ECHO_FREEZE", 0) - 25
            adjusted["ECHO_THROW"]   = adjusted.get("ECHO_THROW", 0) - 15

        return adjusted

    def summary(self) -> str:
        """Human-readable set state summary for the console."""
        s = self.get_snapshot()
        lines = [
            f"🎪 Set State [{s.set_phase.upper()}]  mix #{s.mix_count}  "
            f"session={s.session_duration/60:.0f}min",
            f"   Energy={s.energy_rolling:.2f}  Intensity={s.intensity_rolling:.2f}",
            f"   Breather={s.time_since_breather/60:.1f}min ago  "
            f"HardDrop={s.time_since_hard_drop/60:.1f}min ago",
            f"   VocalFatigue={s.vocal_density_fatigue:.2f}"
        ]
        return "\n".join(lines)