"""
adaptive_executor.py — Neuro-DJ Reactive Transition Executor (Telemetry Wired)
══════════════════════════════════════════════════════════════════════════════
Stages 7 and 8 of the roadmap.

Stage 7 — Drift correction
Stage 8 — Bounded adaptive mixing

This module replaces the passive spin-wait loop in start_set with an 
active perception-action loop that runs for the duration of every transition.
"""

import time
import threading
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any

# ── Adaptation constants ──────────────────────────────────────────────────────
POLL_HZ              = 10        # how often the loop ticks (10 = every 100ms)
MAX_DELAY_BEATS      = 32        # max beats to delay a handoff waiting for readiness
MIN_DELAY_SECS       = 2.0       # minimum seconds to wait before granting handoff
DRIFT_THRESHOLD      = 0.15      # beats of drift before a nudge is applied
DRIFT_NUDGE_MAX_SEC  = 0.05      # max position adjustment (seconds)
DRIFT_COOLDOWN_BEATS = 8         # beats between drift nudges
VOCAL_CLASH_COOLDOWN = 4         # beats between vocal clash events
B_PROMINENT_THRESHOLD = 0.35     # B must be this prominent before handoff
READINESS_FLOOR      = 0.55      # minimum readiness score to allow handoff

@dataclass
class AdaptationLog:
    """Records every adaptation action taken during a transition."""
    actions_taken:    List[str] = field(default_factory=list)
    drift_corrections: int      = 0
    vocal_masks_added: int      = 0
    handoff_delayed:  bool      = False
    handoff_forced:   bool      = False
    final_readiness:  float     = 0.0
    b_groove_beat:    Optional[int] = None    
    a_space_beat:     Optional[int] = None    
    peak_congestion:  float     = 0.0
    peak_drift:       float     = 0.0

class AdaptiveExecutor:
    """Runs the active perception-action loop during a transition."""
    
    def __init__(self, mixer, ears, plan: dict, spb: float, telemetry=None):
        self._mixer    = mixer
        self._ears     = ears
        self._plan     = plan
        self._spb      = spb
        self._telemetry = telemetry  # Stores the telemetry logger
        self._log      = AdaptationLog()

        self._trans_dur   = plan['trans_dur']
        self._tech_id     = plan['recipe'].get('technique_id', 0)
        
        self._beat_count            = 0
        self._exact_beat            = 0.0  # Kept as float for precise chart plotting
        self._last_drift_nudge_beat = -DRIFT_COOLDOWN_BEATS
        self._last_vocal_beat       = -VOCAL_CLASH_COOLDOWN
        self._handoff_granted       = threading.Event()
        self._start_wall            = 0.0

    def run(self) -> AdaptationLog:
        """Blocks until the handoff is ready (or deadline forced)."""
        self._start_wall = time.time()
        deadline         = self._start_wall + self._trans_dur + (MAX_DELAY_BEATS * self._spb)
        interval         = 1.0 / POLL_HZ

        print(f"\n👂 Adaptive executor active: trans={self._trans_dur:.1f}s")

        while not self._handoff_granted.is_set():
            t0 = time.time()
            try:
                self._tick()
            except Exception as e:
                print(f"   ⚠️  Executor tick error: {e}")

            if time.time() >= deadline:
                print(f"   ⏰ Handoff deadline reached — forcing swap")
                self._log.handoff_forced = True
                
                # 📡 LOG: Force Action
                if self._telemetry:
                    self._telemetry.log_action(self._exact_beat, "HANDOFF_FORCED", self._ears.get_state())
                
                self._handoff_granted.set()
                break

            elapsed = time.time() - t0
            time.sleep(max(0.0, interval - elapsed))

        self._log.final_readiness = self._ears.get_state().readiness_score
        return self._log

    def _tick(self):
        state = self._ears.get_state()
        elapsed_secs = time.time() - self._start_wall
        
        self._exact_beat = elapsed_secs / self._spb
        self._beat_count = int(self._exact_beat)

        # 📡 LOG: 10Hz Timeline Tick
        if self._telemetry:
            self._telemetry.log_tick(self._exact_beat, state)

        # Peak stats & Milestones
        if state.overlap_congestion > self._log.peak_congestion:
            self._log.peak_congestion = state.overlap_congestion
        drift_abs = abs(state.phase_offset_beats)
        if drift_abs > self._log.peak_drift:
            self._log.peak_drift = drift_abs

        if state.b_groove_established and self._log.b_groove_beat is None:
            self._log.b_groove_beat = self._beat_count
        if state.a_space_opened and self._log.a_space_beat is None:
            self._log.a_space_beat = self._beat_count

        # Action dispatch
        self._check_vocal_clash(state)
        self._check_drift(state)
        self._check_b_suppression(state)
        self._check_handoff(state, elapsed_secs)

    def _check_vocal_clash(self, state):
        """If live vocal clash detected mid-transition, extend the mid-kill on A."""
        if not state.vocal_clash_live: return
        if self._beat_count - self._last_vocal_beat < VOCAL_CLASH_COOLDOWN: return
        
        # Safety gate: Do not mid-kill if the technique relies on mids (like piano handoffs)
        if self._tech_id in (3, 4, 5, 7): return

        a_pos = self._mixer.get_position("A")
        kill_start = a_pos + 0.1
        kill_end   = kill_start + (2.0 * self._spb)

        try:
            self._mixer.add_eq_event(0, kill_start, 1.0, 0.0, 1.0)
            self._mixer.add_eq_event(0, kill_end,   1.0, 1.0, 1.0)
            self._last_vocal_beat = self._beat_count
            self._log.vocal_masks_added += 1
            
            # 📡 LOG: Vocal Mask Action
            if self._telemetry:
                self._telemetry.log_action(self._exact_beat, "EXTEND_VOCAL_MASK", state)
                
            print(f"   🎤 Vocal clash → mid-kill on A for 2 beats")
        except Exception:
            pass

    def _check_drift(self, state):
        """If beat phase drift exceeds threshold, apply a tiny position nudge to B."""
        if state.drift_confidence < 0.45: return
        drift = state.phase_offset_beats
        if abs(drift) < DRIFT_THRESHOLD: return
        if self._beat_count - self._last_drift_nudge_beat < DRIFT_COOLDOWN_BEATS: return
        
        # Transient guard: don't seek during a drum hit
        if state.b_rms > 0.001 and state.overlap_congestion > 0.85: return 

        correction_secs = max(-DRIFT_NUDGE_MAX_SEC, min(DRIFT_NUDGE_MAX_SEC, -drift * self._spb))

        try:
            new_pos_b = max(0.0, self._mixer.get_position("B") + correction_secs)
            self._mixer.seek("B", new_pos_b)
            self._last_drift_nudge_beat = self._beat_count
            self._log.drift_corrections += 1
            
            # 📡 LOG: Drift Nudge Action
            action_name = f"DRIFT_NUDGE_{correction_secs:+.3f}s"
            if self._telemetry:
                self._telemetry.log_action(self._exact_beat, action_name, state)
                
            print(f"   🎯 Drift {drift:+.3f}b → nudge B {correction_secs:+.3f}s")
        except Exception:
            pass

    def _check_b_suppression(self, state):
        """If B is running but its groove isn't established yet, gentle bass hold."""
        if self._tech_id not in (0, 5): return
        elapsed_secs = time.time() - self._start_wall
        if elapsed_secs < self._trans_dur * 0.5: return   
        if state.b_groove_established or state.b_rms < 0.02: return

        if any('B_BASS_HOLD' in a for a in self._log.actions_taken): return

        try:
            b_pos = self._mixer.get_position("B")
            self._mixer.add_eq_event(1, b_pos, 0.6, 1.0, 1.0)
            self._mixer.add_eq_event(1, b_pos + (4.0 * self._spb), 1.0, 1.0, 1.0)
            
            self._log.actions_taken.append("B_BASS_HOLD")
            
            # 📡 LOG: Bass Suppression
            if self._telemetry:
                self._telemetry.log_action(self._exact_beat, "B_BASS_HOLD", state)
                
            print(f"   🎹 B groove not established — gentle bass hold")
        except Exception:
            pass

    def _check_handoff(self, state, elapsed_secs: float):
        """Decide whether the handoff is ready to happen."""
        if elapsed_secs < MIN_DELAY_SECS: return
        if (elapsed_secs / max(self._trans_dur, 1.0)) < 0.90: return
        if self._mixer.is_transitioning(): return   

        if self._tech_id in (3, 7):
            if self._telemetry:
                self._telemetry.log_action(self._exact_beat, "HANDOFF_GRANTED_ECHO", state)
            self._handoff_granted.set()
            return

        readiness = state.readiness_score
        b_ready   = state.b_groove_established
        beats_past_plan = (elapsed_secs - self._trans_dur) / self._spb
        within_delay    = beats_past_plan <= MAX_DELAY_BEATS

        if readiness >= READINESS_FLOOR and (b_ready or not within_delay):
            action = "HANDOFF_GRANTED" if b_ready else "HANDOFF_GRANTED_DELAYED"
            
            # 📡 LOG: Final Handoff Decision
            if self._telemetry:
                self._telemetry.log_action(self._exact_beat, action, state)
                
            self._handoff_granted.set()