"""
live_ears.py — Neuro-DJ Live Perception Module
═══════════════════════════════════════════════
Stage 6 of the roadmap: the system keeps listening during playback.

A precomputed plan is only as good as the offline analysis.
Offline analysis has errors. Tracks have unexpected density changes.
The phase drift accumulates over 60+ second blends.

This module runs in its own thread OUTSIDE the audio callback.
It reads the visual buffer from C++ (256-sample decimated waveform data)
and computes rolling estimates every beat.

What it estimates:
  1. Beat/phase offset between A and B
  2. Drift trend over time (is it getting worse?)
  3. Overlap congestion (are both decks too loud/dense simultaneously?)
  4. Vocal clash activity (are both vocal bands active right now?)
  5. B's groove establishment (is B's rhythm felt by the crowd yet?)
  6. A's space opening (has A opened enough space for B to take over?)
  7. Handoff readiness (overall: is it safe to commit to B?)

Output: a LiveState object that the transition executor reads to make
        bounded real-time adjustments (Stage 8).

Architecture:
  - Runs at 10 Hz (every 100ms) — one analysis per ~11 beats at 112 BPM
  - Reads mixer.get_visual_buffer() — no audio callback involvement
  - Maintains a 16-sample rolling history for trend detection
  - Writes to a thread-safe LiveState dataclass
  - The transition executor reads LiveState (non-blocking) to decide
    whether to nudge EQ events or extend/shorten the current phase

Critical constraint:
  This module NEVER calls any function that takes > 50ms.
  No HPSS. No librosa.load(). No file I/O.
  Only numpy operations on the 512-sample visual buffer.
"""

import threading
import time
import numpy as np
from dataclasses import dataclass, field
from typing import Optional
import collections


# ── Live state dataclass ──────────────────────────────────────────────────────

@dataclass
class LiveState:
    """
    Thread-safe snapshot of current playback state.
    Written by LiveEars thread. Read by transition executor.
    All values are estimates with confidence scores.
    """
    # Phase and drift
    phase_offset_beats: float = 0.0       # A vs B beat phase offset (−1 to +1 beats)
    drift_rate:         float = 0.0       # beats per second of drift
    drift_confidence:   float = 0.0       # 0–1 reliability of phase estimate

    # Overlap congestion
    overlap_congestion: float = 0.0       # 0 (clean) → 1 (both decks at full density)
    a_rms:              float = 0.0       # A's current RMS level
    b_rms:              float = 0.0       # B's current RMS level

    # Vocal activity (estimated from spectral shape of visual buffer)
    a_vocal_active:     bool  = False
    b_vocal_active:     bool  = False
    vocal_clash_live:   bool  = False

    # B's readiness
    b_groove_established: bool  = False   # B's rhythm is felt (RMS stable, rising)
    b_entry_beats:        int   = 0       # how many beats B has been playing
    b_prominence:         float = 0.0     # B's energy relative to A (0–1)

    # A's state
    a_space_opened:    bool  = False      # A's density has dropped below threshold
    a_beat_count:      int   = 0         # beats A has been in the transition

    # Handoff readiness
    handoff_ready:     bool  = False      # overall: safe to commit to B
    readiness_score:   float = 0.0       # 0–1 composite score

    # Timestamp
    last_updated:      float = 0.0


class LiveEars:
    """
    Runs in a background thread, polling the C++ mixer's visual buffers
    and computing live overlap state estimates.

    Usage:
        ears = LiveEars(mixer)
        ears.start()
        # During transition:
        state = ears.get_state()
        if state.handoff_ready: do_handoff()
        ears.stop()
    """

    POLL_HZ        = 10         # analyses per second
    HISTORY_LEN    = 32         # rolling history length (samples)
    GROOVE_BEATS   = 16         # beats B must play before groove is "established"
    CONGESTION_THR = 0.75       # above this = both decks too loud
    SPACE_THR      = 0.40       # A below this = opened enough space
    DRIFT_WARN     = 0.15       # beats of drift before we flag it

    # Visual buffer sample rate: 44100 Hz / 4 decimation = 11025 Hz effective
    # At 11025 Hz with 512-pt FFT: bin width = 11025/512 = 21.5 Hz per bin
    VIS_SR         = 11025
    VIS_FFT_N      = 512

    # Frequency band boundaries in FFT bin indices at 11025 Hz / 512-pt FFT
    # bin = freq / (sr/n_fft) = freq / 21.5
    # Low:  20–200 Hz  → bins 1–9
    # Mid:  200–3400 Hz → bins 9–158   (speech/vocal fundamental + harmonics)
    # High: 3400–5512 Hz → bins 158–256
    _BIN_LOW_HI  = 9     # upper edge of low band
    _BIN_MID_HI  = 158   # upper edge of mid band

    def __init__(self, mixer, bpm=112.0):
        self._mixer   = mixer
        self._bpm     = bpm
        self._state   = LiveState()
        self._lock    = threading.Lock()
        self._running = False
        self._thread  = None

        # Rolling history buffers
        self._a_rms_hist   = collections.deque(maxlen=self.HISTORY_LEN)
        self._b_rms_hist   = collections.deque(maxlen=self.HISTORY_LEN)
        self._b_entry_time = None   # wall-clock time B started playing

        # Per-deck rolling peak for adaptive congestion normalisation
        # Avoids the fixed 0.60 assumption which breaks on quiet material
        self._a_peak_rms   = 0.01   # initialised to a small non-zero value
        self._b_peak_rms   = 0.01

        # Phase tracking — 8 ticks = 800ms of history for stability check
        self._phase_history = collections.deque(maxlen=8)
        # Phase estimate stability: how consistent are recent estimates?
        # High variance = noisy / unreliable. Low variance = stable / trustworthy.
        self._phase_stable_ticks = 0   # consecutive ticks where |offset| < DRIFT_WARN

    # ── Public API ────────────────────────────────────────────────────────────

    def set_bpm(self, bpm: float):
        self._bpm = max(60.0, min(200.0, bpm))

    def notify_b_started(self):
        """Call when deck B starts playing (transition fires)."""
        self._b_entry_time = time.time()
        with self._lock:
            self._state.b_entry_beats = 0
            self._state.b_groove_established = False

    def get_state(self) -> LiveState:
        """Non-blocking read of current live state."""
        with self._lock:
            return LiveState(**self._state.__dict__)

    def start(self):
        if self._running:
            return
        self._running = True
        self._thread  = threading.Thread(target=self._loop, daemon=True,
                                          name="LiveEars")
        self._thread.start()

    def stop(self):
        self._running = False
        if self._thread:
            self._thread.join(timeout=2.0)

    # ── Internal loop ─────────────────────────────────────────────────────────

    def _loop(self):
        interval = 1.0 / self.POLL_HZ
        while self._running:
            t0 = time.time()
            try:
                self._tick()
            except Exception as e:
                pass   # never crash the loop
            elapsed = time.time() - t0
            sleep_for = max(0.0, interval - elapsed)
            time.sleep(sleep_for)

    def _multiband(self, buf):
        """
        Split the visual buffer into 3 frequency bands using FFT.
        Returns (low_energy, mid_energy, high_energy) normalised by total.
        """
        if len(buf) < self.VIS_FFT_N:
            buf = np.pad(buf, (0, self.VIS_FFT_N - len(buf)))
        spectrum = np.abs(np.fft.rfft(buf[:self.VIS_FFT_N]))
        total = np.sum(spectrum) + 1e-9
        low  = np.sum(spectrum[1          : self._BIN_LOW_HI ]) / total
        mid  = np.sum(spectrum[self._BIN_LOW_HI : self._BIN_MID_HI]) / total
        high = np.sum(spectrum[self._BIN_MID_HI :               ]) / total
        return float(low), float(mid), float(high)

    def _tick(self):
        """
        Core analysis tick — all fast numpy, no librosa.
        """
        try:
            buf_a = np.array(self._mixer.get_visual_buffer("A"), dtype=np.float32)
            buf_b = np.array(self._mixer.get_visual_buffer("B"), dtype=np.float32)
        except Exception:
            return

        if len(buf_a) == 0 or len(buf_b) == 0:
            return

        # ── RMS energy ────────────────────────────────────────────────────────
        a_rms = float(np.sqrt(np.mean(buf_a ** 2)))
        b_rms = float(np.sqrt(np.mean(buf_b ** 2)))
        self._a_rms_hist.append(a_rms)
        self._b_rms_hist.append(b_rms)

        self._a_peak_rms = max(self._a_peak_rms, a_rms)
        self._b_peak_rms = max(self._b_peak_rms, b_rms)

        # ── Adaptive overlap congestion ───────────────────────────────────────
        a_rel = a_rms / (self._a_peak_rms + 1e-9)   
        b_rel = b_rms / (self._b_peak_rms + 1e-9)   
        congestion = float(np.clip((a_rel + b_rel) / 2.0, 0.0, 1.0))

        # ── Multiband spectral analysis ───────────────────────────────────────
        a_low, a_mid, a_high = self._multiband(buf_a)
        b_low, b_mid, b_high = self._multiband(buf_b)

        # ── Vocal activity — multiband ratio test ─────────────────────────────
        a_vocal = (a_rms > 0.06 and a_mid > 0.48 and a_low < 0.45 and a_high < 0.48)                
        b_vocal = (b_rms > 0.06 and b_mid > 0.48 and b_low < 0.45 and b_high < 0.48)
        vocal_clash = a_vocal and b_vocal

        # ── B groove establishment ────────────────────────────────────────────
        spb   = 60.0 / max(self._bpm, 60.0)
        b_beats = 0
        if self._b_entry_time is not None:
            b_beats = int((time.time() - self._b_entry_time) / spb)

        b_groove = False
        if b_beats >= self.GROOVE_BEATS and b_rms > 0.05:
            if len(self._b_rms_hist) >= 4:
                recent = list(self._b_rms_hist)[-4:]
                rms_slope = float(np.polyfit(range(4), recent, 1)[0])
                b_groove = rms_slope >= -0.002
            else:
                b_groove = True

        # ── A space opening ───────────────────────────────────────────────────
        a_space = False
        if len(self._a_rms_hist) >= 8:
            a_peak = max(list(self._a_rms_hist))
            if a_peak > 0.02:
                a_ratio = a_rms / a_peak
                a_space = a_ratio < self.SPACE_THR

        # ── B prominence ─────────────────────────────────────────────────────
        b_prominence = 0.0
        if a_rms + b_rms > 0.001:
            b_prominence = float(b_rms / (a_rms + b_rms))

        # ── Phase drift estimate ──────────────────────────────────────────────
        phase_offset, corr_conf = self._estimate_phase(buf_a, buf_b)
        self._phase_history.append(phase_offset)
        drift_rate = 0.0
        if len(self._phase_history) >= 4:
            offsets = list(self._phase_history)[-4:]
            drift_rate = float(np.polyfit(range(4), offsets, 1)[0]) * self.POLL_HZ

        # ── Phase stability confidence ────────────────────────────────────────
        if len(self._phase_history) >= 4:
            recent_offsets = list(self._phase_history)[-4:]
            offset_std = float(np.std(recent_offsets))
            stability_conf = float(np.clip(1.0 - offset_std / 0.30, 0.0, 1.0))
            drift_conf = float(np.sqrt(corr_conf * stability_conf))
            if offset_std < 0.05:
                self._phase_stable_ticks += 1
            else:
                self._phase_stable_ticks = 0
        else:
            drift_conf = corr_conf * 0.5   

        # ── Handoff readiness ─────────────────────────────────────────────────
        readiness = 0.0
        if b_groove:                         readiness += 0.35
        if a_space:                          readiness += 0.25
        if not vocal_clash:                  readiness += 0.20
        if b_prominence > 0.35:              readiness += 0.15
        if abs(phase_offset) < self.DRIFT_WARN: readiness += 0.05
        handoff_ready = readiness >= 0.70

        # ── Write state ───────────────────────────────────────────────────────
        with self._lock:
            s = self._state
            s.a_rms              = round(a_rms, 4)
            s.b_rms              = round(b_rms, 4)
            s.overlap_congestion = round(congestion, 3)
            s.a_vocal_active     = a_vocal
            s.b_vocal_active     = b_vocal
            s.vocal_clash_live   = vocal_clash
            s.b_groove_established = b_groove
            s.b_entry_beats      = b_beats
            s.b_prominence       = round(b_prominence, 3)
            s.a_space_opened     = a_space
            s.phase_offset_beats = round(phase_offset, 3)
            s.drift_rate         = round(drift_rate, 4)
            s.drift_confidence   = round(drift_conf, 3)
            s.handoff_ready      = handoff_ready
            s.readiness_score    = round(readiness, 3)
            s.last_updated       = time.time()

    def _estimate_phase(self, buf_a, buf_b):
        """
        Estimate beat phase offset between A and B using transient-emphasized envelope.
        """
        try:
            if len(buf_a) < 64 or len(buf_b) < 64:
                return 0.0, 0.0

            trans_a = np.abs(np.diff(buf_a.astype(np.float32)))
            trans_b = np.abs(np.diff(buf_b.astype(np.float32)))

            kernel  = np.ones(6) / 6
            env_a   = np.convolve(trans_a, kernel, mode='same')
            env_b   = np.convolve(trans_b, kernel, mode='same')

            n = min(len(env_a), len(env_b), 256)
            env_a = env_a[:n]
            env_b = env_b[:n]

            if env_a.std() < 1e-5 or env_b.std() < 1e-5:
                return 0.0, 0.0

            xcorr = np.correlate(env_a - env_a.mean(),
                                  env_b - env_b.mean(), mode='full')
            lags        = np.arange(-n + 1, n)
            peak        = int(np.argmax(np.abs(xcorr)))
            lag_samples = int(lags[peak])

            lag_sec      = lag_samples * (4.0 / 44100.0)
            spb          = 60.0 / max(self._bpm, 60.0)
            offset_beats = float(np.clip(lag_sec / spb, -2.0, 2.0))

            peak_val     = float(np.abs(xcorr[peak]))
            max_possible = float(np.sqrt(np.sum(env_a**2) * np.sum(env_b**2)))
            confidence   = float(np.clip(peak_val / (max_possible + 1e-9), 0.0, 1.0))

            return offset_beats, confidence

        except Exception:
            return 0.0, 0.0