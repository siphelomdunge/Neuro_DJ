"""
auto_prep_folder.py  —  Neuro-DJ Deep Structure Analyser (Rock Solid Edition)
═════════════════════════════════════════════════════════════════════════════
This module analyzes your raw MP3s, extracts 8-beat phrases, isolates vocals,
and writes the blueprint to master_library.json. 

ROCK SOLID UPGRADES:
- Idempotent: Skips files that are already in the JSON.
- Sandboxed: Runs analysis in an isolated subprocess to prevent memory 
  fragmentation and survive C-level segfaults from corrupted MP3s.
"""

import librosa
import numpy as np
import json
import soundfile as sf
import os
import sys
import glob
import warnings
import multiprocessing
import gc
from scipy.signal import find_peaks

# ── 1. Helper Functions (Energy, Stems, Sections) ────────────────────────────

def detect_genre(y_mono, sr, bpm):
    if not (96.0 <= bpm <= 116.0): return 'open'
    stft  = np.abs(librosa.stft(y_mono, n_fft=2048, hop_length=512))
    freqs = librosa.fft_frequencies(sr=sr, n_fft=2048)
    sub_ratio = np.mean(stft[freqs < 100]) / (np.mean(stft) + 1e-9)
    centroid  = float(np.mean(librosa.feature.spectral_centroid(y=y_mono, sr=sr)))
    return 'amapiano' if sub_ratio > 0.12 and centroid < 3200.0 else 'open'

def detect_mix_character(y_mono, sr):
    try:
        window = min(32.0, float(librosa.get_duration(y=y_mono, sr=sr)) * 0.15)
        y_open = y_mono[:int(window * sr)]
        if len(y_open) < sr: return 'clean_intro'
        rms_total = float(np.sqrt(np.mean(y_open**2)))
        if rms_total < 0.015: return 'clean_intro'

        stft  = np.abs(librosa.stft(y_open, n_fft=512, hop_length=128))
        freqs = librosa.fft_frequencies(sr=sr, n_fft=512)
        vmask = (freqs >= 300) & (freqs <= 3400)
        bmask = freqs < 200
        
        vocal_ratio = float(np.mean(stft[vmask])) / (float(np.mean(stft)) + 1e-9) if vmask.any() else 0
        bass_ratio  = float(np.mean(stft[bmask])) / (float(np.mean(stft)) + 1e-9) if bmask.any() else 0

        if vocal_ratio > 0.45: return 'vocal_heavy'
        elif bass_ratio > 0.18: return 'drum_heavy'
        elif vocal_ratio > 0.30: return 'melodic'
        elif rms_total < 0.04: return 'sparse'
        return 'clean_intro'
    except:
        return 'clean_intro'

def find_outro_beat(beat_times, rms, sr, total_duration):
    max_rms = np.max(rms) + 1e-9
    for window_beats in (96, 128, 160):
        start_idx = max(0, len(beat_times) - window_beats)
        for i in range(start_idx, len(beat_times) - 32, 32):
            s = librosa.time_to_frames(beat_times[i], sr=sr)
            e = librosa.time_to_frames(beat_times[i+32], sr=sr)
            phrase_rms = np.mean(rms[s:min(e, len(rms)-1)])
            if phrase_rms < max_rms * 0.40:
                return i, float(beat_times[i])
    fb = max(0, len(beat_times) - 65)
    return fb, float(beat_times[fb])

def analyze_stems(y_mono, sr):
    try:
        if sr != 22050:
            y_mono = librosa.resample(y_mono, orig_sr=sr, target_sr=22050)
            sr = 22050
        harmonic, percussive = librosa.effects.hpss(y_mono, margin=3.0)
        
        # Vocals
        S_harm = np.abs(librosa.stft(harmonic, n_fft=1024, hop_length=256))
        freqs  = librosa.fft_frequencies(sr=sr, n_fft=1024)
        vmask  = (freqs >= 300) & (freqs <= 3400)
        vocal_energy = np.mean(S_harm[vmask, :], axis=0)
        smf = int(sr/256*0.5)
        vocal_smooth = np.convolve(vocal_energy, np.ones(smf)/smf, mode='same')
        vocal_active = vocal_smooth > np.percentile(vocal_smooth, 55)
        frame_times = librosa.frames_to_time(np.arange(len(vocal_active)), sr=sr, hop_length=256)
        
        vocal_regions, in_r, r_start = [], False, 0.0
        for i, a in enumerate(vocal_active):
            if a and not in_r:  
                r_start = float(frame_times[i]); in_r = True
            elif not a and in_r:
                if float(frame_times[i]) - r_start >= 1.5:
                    vocal_regions.append([round(r_start,2), round(float(frame_times[i]),2)])
                in_r = False
        if in_r: vocal_regions.append([round(r_start,2), round(float(frame_times[-1]),2)])
        
        # Log Drums
        S_perc = np.abs(librosa.stft(percussive, n_fft=1024, hop_length=256))
        bmask = freqs < 200
        bass_e = np.mean(S_perc[bmask,:], axis=0)
        bass_t = librosa.frames_to_time(np.arange(len(bass_e)), sr=sr, hop_length=256)
        mdist = int(sr/256*0.4)
        pk, _ = find_peaks(bass_e, height=np.percentile(bass_e,78), distance=max(1,mdist))
        log_drum_hits = [round(float(bass_t[p]),3) for p in pk if bass_t[p] > 5.0]
        
        return {
            'has_vocals': len(vocal_regions) > 0,
            'vocal_regions': vocal_regions,
            'log_drum_hits': log_drum_hits[:50]
        }
    except Exception:
        return {'has_vocals': False, 'vocal_regions': [], 'log_drum_hits': []}

# ── 2. The Core Analysis Logic ───────────────────────────────────────────────

def _worker_process(input_path, output_queue):
    """Runs inside the isolated Subprocess."""
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            y, sr = librosa.load(input_path, sr=44100, mono=False)
        y_mono = librosa.to_mono(y)
        total_dur = float(librosa.get_duration(y=y_mono, sr=sr))

        # 44.1kHz High-Res Extractions
        onset_env = librosa.onset.onset_strength(y=y_mono, sr=sr, aggregate=np.median)
        tempo, beat_frames = librosa.beat.beat_track(onset_envelope=onset_env, sr=sr, start_bpm=112.0)
        bpm = float(tempo[0] if isinstance(tempo, np.ndarray) else tempo)
        beat_times = librosa.frames_to_time(beat_frames, sr=sr)
        
        chroma = librosa.feature.chroma_cqt(y=y_mono, sr=sr)
        keys = ['C','C#','D','D#','E','F','F#','G','G#','A','A#','B']
        detected_key = keys[int(np.argmax(np.mean(chroma, axis=1)))]
        
        cent = librosa.feature.spectral_centroid(y=y_mono, sr=sr)
        energy_score = "High" if float(np.mean(cent)) > 2500 else "Low/Chill"
        
        rms = librosa.feature.rms(y=y_mono)[0]
        _, opt_mix_out = find_outro_beat(beat_times, rms, sr, total_dur)
        outro_start = float(beat_times[-33]) if len(beat_times) > 33 else total_dur * 0.75

        # Save WAV & Free memory
        base = input_path.replace(".mp3","").replace(".wav","")
        output_wav = base + "_ready.wav"
        sf.write(output_wav, y.T if y.ndim > 1 else y, sr)
        
        del y, y_mono, onset_env, chroma, cent, rms
        gc.collect()

        # 11kHz Low-Res Extractions
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            y_low, sr_low = librosa.load(input_path, sr=11025, mono=True)

        genre = detect_genre(y_low, sr_low, bpm)
        mix_character = detect_mix_character(y_low, sr_low)
        stems = analyze_stems(y_low, sr_low)
        
        # Phrases 
        try:
            from phrase_analyzer import analyse_phrases, get_best_exit_phrases, get_best_entry_phrases
            phrases = analyse_phrases(y_low, sr_low, beat_times, bpm, [])
            exits = [p['start'] for p in get_best_exit_phrases(phrases)[:6]]
            entries = [p['start'] for p in get_best_entry_phrases(phrases)[:5]]
        except ImportError:
            phrases, exits, entries = [], [], []

        result = {
            "filename": os.path.abspath(output_wav),
            "bpm": round(bpm, 2),
            "key": detected_key,
            "energy": energy_score,
            "genre": genre,
            "mix_character": mix_character,
            "stems": stems,
            "phrases": phrases,
            "best_exit_phrases": exits,
            "best_entry_phrases": entries,
            "zones": {
                "optimal_mix_out": round(opt_mix_out, 3),
                "outro_start": round(outro_start, 3)
            }
        }
        output_queue.put({"status": "success", "data": result})

    except Exception as e:
        output_queue.put({"status": "error", "error": str(e)})

# ── 3. The Idempotent Folder Manager ─────────────────────────────────────────

def _save_library(lib_data):
    """Atomic save to prevent JSON corruption."""
    lib_sorted = sorted(lib_data, key=lambda x: x.get('bpm', 112))
    tmp = "master_library.json.tmp"
    with open(tmp, 'w') as f:
        json.dump(lib_sorted, f, indent=4)
    os.replace(tmp, "master_library.json")

def process_folder(folder_path):
    files = []
    for ext in ('*.mp3', '*.wav'):
        files.extend(glob.glob(os.path.join(folder_path, ext)))
    files = [f for f in files if "_ready.wav" not in f]

    if not files:
        print("⚠️ No tracks found.")
        return

    # Idempotency Check
    master_library = []
    processed_basenames = set()
    if os.path.exists("master_library.json"):
        try:
            with open("master_library.json", "r") as jf:
                master_library = json.load(jf)
            for track in master_library:
                base = os.path.basename(track['filename']).replace('_ready.wav', '')
                processed_basenames.add(base)
        except Exception:
            pass

    todo = [f for f in files if os.path.splitext(os.path.basename(f))[0] not in processed_basenames]
    
    if not todo:
        print("✅ All tracks already in master_library.json. Nothing to do!")
        return

    print(f"📂 Processing {len(todo)} new tracks...")
    failed = []

    for i, filepath in enumerate(todo):
        print(f"\n[{i+1}/{len(todo)}] Analyzing {os.path.basename(filepath)}")
        
        # Subprocess Sandbox
        q = multiprocessing.Queue()
        proc = multiprocessing.Process(target=_worker_process, args=(filepath, q))
        proc.start()
        
        # Timeout safety (e.g., infinite loop on a corrupted file)
        proc.join(timeout=240) 
        
        if proc.is_alive():
            print("   ⏳ Timeout. Terminating process...")
            proc.terminate()
            proc.join()
            failed.append(filepath)
            continue

        if not q.empty():
            res = q.get()
            if res["status"] == "success":
                master_library.append(res["data"])
                _save_library(master_library)
                print(f"   ✅ Saved.")
            else:
                print(f"   ❌ Error: {res['error']}")
                failed.append(filepath)
        else:
            print(f"   ❌ Process crashed (Segfault).")
            failed.append(filepath)

    print(f"\n{'─'*60}\n✅ Library updated: {len(master_library)} total tracks.\n{'─'*60}")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python auto_prep_folder.py ./my_music_folder")
    else:
        # Required for safe Windows/macOS multiprocessing
        multiprocessing.freeze_support() 
        process_folder(sys.argv[1])