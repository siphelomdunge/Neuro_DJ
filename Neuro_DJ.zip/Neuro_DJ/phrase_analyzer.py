"""
phrase_analyzer.py — Neuro-DJ Phrase Intelligence Layer
═══════════════════════════════════════════════════════
Stage 2 of the roadmap: move from section labels to phrase-level understanding.

A "section" is 30–120 seconds labelled intro/drop/outro.
A "phrase" is 8–32 beats with a musical function label.

The difference matters enormously for DJ decisions:
  Section: "breakdown"
  Phrase:  "8-beat sparse drum foundation — no bass, no vocal, log drums only"

What this module produces per track (added to master_library.json):
  phrases: [ { start, end, function, mixability, ... }, ... ]
"""

import librosa
import numpy as np
import warnings

# The 9 core musical functions, ordered roughly from most mixable to least
PHRASE_FUNCTIONS = [
    'dj_friendly_outro',
    'decompression',
    'drum_foundation',
    'harmonic_bed',
    'tension_build',
    'vocal_spotlight',
    'bass_showcase',
    'release_peak',
    'fake_outro'
]

def analyse_phrases(y_mono, sr, beat_times, bpm, structure_map, beats_per_phrase=8):
    """
    Chops the audio into 8-beat phrases and analyzes the acoustic properties
    of each chunk to determine its 'mixability'.
    """
    if len(beat_times) < beats_per_phrase:
        return []

    phrases = []
    total_dur = float(librosa.get_duration(y=y_mono, sr=sr))
    
    # Run a quick HPSS for the whole track to extract vocal/bass densities efficiently
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        harmonic, percussive = librosa.effects.hpss(y_mono, margin=2.0)
    
    # Pre-compute spectrograms to save CPU during the loop
    S_harm = np.abs(librosa.stft(harmonic, n_fft=512, hop_length=256))
    S_perc = np.abs(librosa.stft(percussive, n_fft=512, hop_length=256))
    freqs = librosa.fft_frequencies(sr=sr, n_fft=512)
    
    vocal_mask = (freqs >= 300) & (freqs <= 3400)
    bass_mask  = freqs < 200
    
    # Loop through the track in 8-beat chunks
    for i in range(0, len(beat_times) - beats_per_phrase, beats_per_phrase):
        start_time = float(beat_times[i])
        end_time   = float(beat_times[i + beats_per_phrase])
        
        # Convert times to frame indices
        start_frame = librosa.time_to_frames(start_time, sr=sr, hop_length=256)
        end_frame   = librosa.time_to_frames(end_time, sr=sr, hop_length=256)
        
        if start_frame >= end_frame or end_frame > S_harm.shape[1]:
            continue
            
        # Extract features for this specific 8-beat window
        h_chunk = S_harm[:, start_frame:end_frame]
        p_chunk = S_perc[:, start_frame:end_frame]
        
        total_energy = np.sum(h_chunk) + np.sum(p_chunk) + 1e-9
        
        vocal_energy = np.sum(h_chunk[vocal_mask, :])
        bass_energy  = np.sum(p_chunk[bass_mask, :])
        
        vocal_density = float(vocal_energy / total_energy)
        bass_density  = float(bass_energy / total_energy)
        harm_density  = float(np.sum(h_chunk) / total_energy)
        perc_density  = float(np.sum(p_chunk) / total_energy)
        
        # Determine track position (0.0 to 1.0)
        pos = start_time / total_dur
        
        # ── Functional Labeling & Mixability Scoring ──
        # Base mixability on how "empty" the phrase is
        mixability = 1.0 - (vocal_density * 1.5) - (bass_density * 1.0)
        
        if pos > 0.80 and vocal_density < 0.2 and bass_density < 0.2:
            func = 'dj_friendly_outro'
            mixability += 0.4
        elif pos < 0.15 and vocal_density < 0.15:
            func = 'drum_foundation' if perc_density > harm_density else 'harmonic_bed'
            mixability += 0.3
        elif vocal_density > 0.4:
            func = 'vocal_spotlight'
            mixability -= 0.5
        elif bass_density > 0.35 and pos > 0.2:
            func = 'release_peak'
            mixability -= 0.6
        elif bass_density > 0.25:
            func = 'bass_showcase'
            mixability -= 0.2
        elif harm_density > 0.6:
            func = 'tension_build'
            mixability -= 0.1
        elif pos > 0.5 and bass_density < 0.1 and perc_density < 0.2:
            func = 'decompression'
            mixability += 0.2
        else:
            func = 'drum_foundation'
            
        mixability = float(np.clip(mixability, 0.0, 1.0))
        
        phrases.append({
            'start': round(start_time, 3),
            'end': round(end_time, 3),
            'beat_count': beats_per_phrase,
            'function': func,
            'vocal_density': round(vocal_density, 3),
            'bass_density': round(bass_density, 3),
            'harmonic_density': round(harm_density, 3),
            'percussive_density': round(perc_density, 3),
            'mixability': round(mixability, 3)
        })

    return phrases

def get_best_exit_phrases(phrases, min_mixability=0.6, max_count=6):
    """
    Return the top candidate exit phrases for Track A.
    Must be in the last 40% of the track.
    """
    if not phrases:
        return []

    total_dur = max(p['end'] for p in phrases)

    candidates = [
        p for p in phrases
        if p['mixability'] >= min_mixability
        and p['start'] >= total_dur * 0.60   # last 40% of track
        and p['function'] not in ('release_peak', 'vocal_spotlight')  # never mid-drop
    ]
    return sorted(candidates, key=lambda p: -p['mixability'])[:max_count]

def get_best_entry_phrases(phrases, max_count=5):
    """
    Return the top candidate entry phrases for B.
    B should enter at a clean, relatively sparse moment so the crowd
    hears B building without it competing with A.
    """
    if not phrases:
        return []

    total_dur = max(p['end'] for p in phrases)

    candidates = [
        p for p in phrases
        if p['start'] <= total_dur * 0.40   # first 40% of track
        and p['function'] not in ('release_peak', 'vocal_spotlight')
    ]
    return sorted(candidates, key=lambda p: -p['mixability'])[:max_count]